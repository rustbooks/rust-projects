// src/ui/bridge.rs
//
// The bridge between domain logic and the Slint-generated UI.
// This module is compiled ONLY as part of the binary target (main.rs).
// It cannot be in the library (lib.rs) because it depends on Slint-generated
// types (AppWindow, FileItem, etc.) produced by `slint::include_modules!()`.

use file_browser::app::{AppState, ClipboardOp};
use file_browser::domain::{FileCategory, FileEntry};
use file_browser::fs::{repository, search::SearchQuery};

use slint::{ComponentHandle, ModelRc, SharedString, VecModel, Weak};
use std::path::PathBuf;
use std::sync::{atomic::{AtomicBool, Ordering}, Arc};
use parking_lot::Mutex;

use crate::{AppWindow, slint_types::{FileItem as SlintFileItem, BreadcrumbItem, SidebarItem}};

// ── Type converters ───────────────────────────────────────────────────────────

pub fn entry_to_slint(e: &FileEntry) -> SlintFileItem {
    SlintFileItem {
        name:         e.name.clone().into(),
        path:         e.path_str().into(),
        is_dir:       e.is_dir(),
        size:         e.size_display().into(),
        modified:     e.modified_display().into(),
        file_type:    category_str(&e.category).into(),
        is_selected:  e.is_selected,
        is_hidden:    e.is_hidden,
        extension:    e.extension.clone().into(),
        icon:         e.icon().into(),
        is_encrypted: e.is_encrypted,
    }
}

fn category_str(cat: &FileCategory) -> &'static str {
    match cat {
        FileCategory::Folder     => "folder",
        FileCategory::Image      => "image",
        FileCategory::Video      => "video",
        FileCategory::Audio      => "audio",
        FileCategory::Document   => "document",
        FileCategory::Code       => "code",
        FileCategory::Archive    => "archive",
        FileCategory::Text       => "text",
        FileCategory::Executable | FileCategory::Other => "other",
    }
}

pub fn build_file_model(entries: &[FileEntry]) -> ModelRc<SlintFileItem> {
    ModelRc::new(VecModel::from(entries.iter().map(entry_to_slint).collect::<Vec<_>>()))
}

pub fn build_breadcrumbs(path: &std::path::Path) -> ModelRc<BreadcrumbItem> {
    let mut crumbs = Vec::new();
    let mut accumulated = PathBuf::new();
    for component in path.components() {
        use std::path::Component::*;
        accumulated.push(component);
        let label = match component {
            RootDir   => "⬤".to_string(),
            Normal(n) => n.to_string_lossy().into_owned(),
            Prefix(p) => p.as_os_str().to_string_lossy().into_owned(),
            _         => continue,
        };
        crumbs.push(BreadcrumbItem {
            label: label.into(),
            path:  accumulated.to_string_lossy().to_string().into(),
        });
    }
    ModelRc::new(VecModel::from(crumbs))
}

pub fn build_sidebar_items(
    items: &[(&str, PathBuf)],
    icon_for: impl Fn(&str) -> &'static str,
) -> ModelRc<SidebarItem> {
    let v: Vec<SidebarItem> = items.iter().map(|(label, path)| SidebarItem {
        label:     SharedString::from(*label),
        path:      path.to_string_lossy().to_string().into(),
        icon:      icon_for(label).into(),
        is_active: false,
    }).collect();
    ModelRc::new(VecModel::from(v))
}

fn build_favorite_model(paths: &[String]) -> ModelRc<SidebarItem> {
    let items: Vec<SidebarItem> = paths.iter().map(|p| {
        let label = PathBuf::from(p)
            .file_name()
            .map(|n| n.to_string_lossy().to_string())
            .unwrap_or_else(|| p.clone());
        SidebarItem { label: label.into(), path: p.clone().into(), icon: "★".into(), is_active: false }
    }).collect();
    ModelRc::new(VecModel::from(items))
}

// ── Toast ─────────────────────────────────────────────────────────────────────

fn show_toast(weak: &Weak<AppWindow>, msg: &str, error: bool) {
    let msg  = msg.to_string();
    let w    = weak.clone();
    let _    = slint::invoke_from_event_loop(move || {
        if let Some(win) = w.upgrade() {
            win.set_toast_message(msg.into());
            win.set_toast_error(error);
            win.set_toast_visible(true);
        }
    });
    let w2 = weak.clone();
    std::thread::spawn(move || {
        std::thread::sleep(std::time::Duration::from_secs(3));
        let _ = slint::invoke_from_event_loop(move || {
            if let Some(win) = w2.upgrade() { win.set_toast_visible(false); }
        });
    });
}

// ── Navigation ────────────────────────────────────────────────────────────────

pub async fn navigate_to_path(state: Arc<Mutex<AppState>>, weak: Weak<AppWindow>, path: PathBuf) {
    {
        let w = weak.clone();
        let _ = slint::invoke_from_event_loop(move || {
            if let Some(win) = w.upgrade() { win.set_loading(true); }
        });
    }

    let show_hidden = state.lock().show_hidden;
    let sort_by  = state.lock().sort_by.clone();
    let sort_asc = state.lock().sort_ascending;
    let path2 = path.clone();

    let result = tokio::task::spawn_blocking(move || {
        repository::list_dir_sorted(&path2, &sort_by, sort_asc)
    }).await;

    match result.ok().and_then(|r| r.ok()) {
        Some(mut entries) => {
            if !show_hidden { entries.retain(|e| !e.is_hidden); }
            let count  = entries.len();
            let model  = build_file_model(&entries);
            let crumbs = build_breadcrumbs(&path);
            {
                let mut st = state.lock();
                st.history_push(path.clone());
                st.current_path = path.clone();
                st.entries      = entries;
                st.config.add_recent(path.to_string_lossy());
                let _ = st.config.save();
            }
            let path_str = path.to_string_lossy().to_string();
            let status   = format!("{count} items  |  {path_str}");
            let can_back = state.lock().can_back();
            let can_fwd  = state.lock().can_forward();
            let _ = slint::invoke_from_event_loop(move || {
                if let Some(win) = weak.upgrade() {
                    win.set_files(model);
                    win.set_breadcrumbs(crumbs);
                    win.set_current_path(path_str.into());
                    win.set_status_text(status.into());
                    win.set_loading(false);
                    win.set_selected_count(0);
                    win.set_can_back(can_back);
                    win.set_can_forward(can_fwd);
                }
            });
        }
        None => {
            show_toast(&weak, "Cannot access this location — permission denied", true);
            let _ = slint::invoke_from_event_loop(move || {
                if let Some(win) = weak.upgrade() { win.set_loading(false); }
            });
        }
    }
}

pub async fn reload_dir(state: Arc<Mutex<AppState>>, weak: Weak<AppWindow>, path: PathBuf) {
    navigate_to_path(state, weak, path).await;
}

// ── Callback wiring ───────────────────────────────────────────────────────────

pub fn wire_callbacks(window: &AppWindow, state: Arc<Mutex<AppState>>, rt: Arc<tokio::runtime::Runtime>) {
    let weak = window.as_weak();

    macro_rules! cb {
        ($s:expr, $r:expr, $w:expr, $body:expr) => {{
            let (s, r, w) = ($s.clone(), $r.clone(), $w.clone());
            move || { let (s, r, w) = (s.clone(), r.clone(), w.clone()); $body }
        }};
    }

    // navigate_to
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_navigate_to(move |p| { let(s2,w2)=(s.clone(),w.clone()); r.spawn(async move { navigate_to_path(s2,w2,PathBuf::from(p.as_str())).await; }); }); }

    // navigate_back
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_navigate_back(move || { if let Some(p)=s.lock().history_back() { let(s2,w2)=(s.clone(),w.clone()); r.spawn(async move { navigate_to_path(s2,w2,p).await; }); } }); }

    // navigate_forward
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_navigate_forward(move || { if let Some(p)=s.lock().history_forward() { let(s2,w2)=(s.clone(),w.clone()); r.spawn(async move { navigate_to_path(s2,w2,p).await; }); } }); }

    // navigate_up
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_navigate_up(move || { if let Some(p)=s.lock().current_path.parent().map(|x|x.to_owned()) { let(s2,w2)=(s.clone(),w.clone()); r.spawn(async move { navigate_to_path(s2,w2,p).await; }); } }); }

    // navigate_home
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_navigate_home(move || { let home=dirs::home_dir().unwrap_or_else(||PathBuf::from("/")); let(s2,w2)=(s.clone(),w.clone()); r.spawn(async move { navigate_to_path(s2,w2,home).await; }); }); }

    // refresh
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_refresh(move || { let p=s.lock().current_path.clone(); let(s2,w2)=(s.clone(),w.clone()); r.spawn(async move { reload_dir(s2,w2,p).await; }); }); }

    // open_item
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_open_item(move |i| {
          if let Some(e)=s.lock().entries.get(i as usize).cloned() {
              if e.is_dir() { let(s2,w2)=(s.clone(),w.clone()); r.spawn(async move { navigate_to_path(s2,w2,e.path).await; }); }
              else { let _ = open::that(&e.path); }
          }
      }); }

    // select_item
    { let (s,w)=(state.clone(),weak.clone());
      window.on_select_item(move |idx,multi| {
          let mut st=s.lock();
          if !multi { for e in st.entries.iter_mut() { e.is_selected=false; } }
          if let Some(e)=st.entries.get_mut(idx as usize) { e.is_selected=!e.is_selected; }
          let count=st.entries.iter().filter(|e|e.is_selected).count();
          let model=build_file_model(&st.entries); drop(st);
          let w2=w.clone();
          let _=slint::invoke_from_event_loop(move || { if let Some(win)=w2.upgrade() { win.set_files(model); win.set_selected_count(count as i32); } });
      }); }

    // sort_by_key
    { let (s,w)=(state.clone(),weak.clone());
      window.on_sort_by_key(move |key| {
          let mut st=s.lock();
          if st.sort_by==key.as_str() { st.sort_ascending=!st.sort_ascending; } else { st.sort_by=key.to_string(); st.sort_ascending=true; }
          let (by,asc)=(st.sort_by.clone(),st.sort_ascending);
          file_browser::domain::sort_entries(&mut st.entries,&by,asc);
          let model=build_file_model(&st.entries); let (by2,asc2)=(by,asc); drop(st);
          let w2=w.clone();
          let _=slint::invoke_from_event_loop(move || { if let Some(win)=w2.upgrade() { win.set_files(model); win.set_sort_by(by2.into()); win.set_sort_ascending(asc2); } });
      }); }

    // search_changed
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      let cancel=Arc::new(AtomicBool::new(false));
      window.on_search_changed(move |q| {
          let qs=q.to_string();
          cancel.store(true,Ordering::Relaxed);
          let (path,show_hidden)={ let st=s.lock(); (st.current_path.clone(),st.show_hidden) };
          if qs.is_empty() { let(s2,w2,p)=(s.clone(),w.clone(),path.clone()); r.spawn(async move { reload_dir(s2,w2,p).await; }); return; }
          let c2=Arc::new(AtomicBool::new(false));
          let (s2,w2,cc)=(s.clone(),w.clone(),c2.clone());
          r.spawn(async move {
              let query=SearchQuery { name:qs, include_hidden:show_hidden, ..Default::default() };
              let results=tokio::task::spawn_blocking(move || file_browser::fs::search::search_dir(&path,&query,500,cc)).await.ok().and_then(|r|r.ok()).unwrap_or_default();
              let model=build_file_model(&results); let status=format!("{} result(s)",results.len());
              s2.lock().entries=results;
              let _=slint::invoke_from_event_loop(move || { if let Some(win)=w2.upgrade() { win.set_files(model); win.set_status_text(status.into()); win.set_loading(false); } });
          });
      }); }

    // toggle_theme
    { let (s,w)=(state.clone(),weak.clone());
      window.on_toggle_theme(move || {
          let dark={ let mut st=s.lock(); st.config.dark_mode=!st.config.dark_mode; let _=st.config.save(); st.config.dark_mode };
          let w2=w.clone(); let _=slint::invoke_from_event_loop(move || { if let Some(win)=w2.upgrade() { win.set_dark_mode(dark); } });
      }); }

    // toggle_hidden
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_toggle_hidden(move || {
          let (path,show)={ let mut st=s.lock(); st.show_hidden=!st.show_hidden; st.config.show_hidden_files=st.show_hidden; (st.current_path.clone(),st.show_hidden) };
          let w2=w.clone(); let _=slint::invoke_from_event_loop(move || { if let Some(win)=w2.upgrade() { win.set_show_hidden(show); } });
          let (s2,w3)=(s.clone(),w.clone()); r.spawn(async move { reload_dir(s2,w3,path).await; });
      }); }

    // toggle_view_mode
    { let (s,w)=(state.clone(),weak.clone());
      window.on_toggle_view_mode(move || {
          let mode={ let mut st=s.lock(); st.config.view_mode=if st.config.view_mode=="grid" {"list".into()} else {"grid".into()}; let _=st.config.save(); st.config.view_mode.clone() };
          let w2=w.clone(); let _=slint::invoke_from_event_loop(move || { if let Some(win)=w2.upgrade() { win.set_view_mode(mode.into()); } });
      }); }

    // open_folder_dialog
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_open_folder_dialog(move || {
          let (s2,w2)=(s.clone(),w.clone());
          r.spawn(async move { if let Some(f)=rfd::AsyncFileDialog::new().set_title("Open Folder").pick_folder().await { navigate_to_path(s2,w2,f.path().to_owned()).await; } });
      }); }

    // new_folder_confirm
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_new_folder_confirm(move |name| {
          let (path,cur)={ let st=s.lock(); (st.current_path.join(name.as_str()),st.current_path.clone()) };
          let (s2,w2)=(s.clone(),w.clone());
          r.spawn(async move { match repository::create_dir(&path) { Ok(_)=>{ reload_dir(s2,w2,cur).await; } Err(e)=>{ show_toast(&w2,&e.to_string(),true); } } });
      }); }

    // rename_confirm
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_rename_confirm(move |new_name| {
          let (src,cur)={ let st=s.lock(); (st.entries.iter().find(|e|e.is_selected).map(|e|e.path.clone()), st.current_path.clone()) };
          if let Some(src_path)=src {
              let dst=src_path.parent().unwrap_or(&cur).join(new_name.as_str());
              let (s2,w2)=(s.clone(),w.clone());
              r.spawn(async move { match repository::rename(&src_path,&dst) { Ok(_)=>{ reload_dir(s2,w2,cur).await; } Err(e)=>{ show_toast(&w2,&e.to_string(),true); } } });
          }
      }); }

    // delete_confirm
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_delete_confirm(move || {
          let (to_del,cur)={ let st=s.lock(); (st.entries.iter().filter(|e|e.is_selected).map(|e|e.path.clone()).collect::<Vec<_>>(), st.current_path.clone()) };
          let (s2,w2)=(s.clone(),w.clone());
          r.spawn(async move {
              let mut errs=Vec::new();
              for p in &to_del { if let Err(e)=repository::delete_entry(p) { errs.push(e.to_string()); } }
              if !errs.is_empty() { show_toast(&w2,&errs.join("; "),true); }
              reload_dir(s2,w2,cur).await;
          });
      }); }

    // copy / cut / paste
    { let s=state.clone(); window.on_copy_items(move || { s.lock().copy_selected(); }); }
    { let s=state.clone(); window.on_cut_items(move || { s.lock().cut_selected(); }); }
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_paste_items(move || {
          let (op,cur)={ let mut st=s.lock(); let c=st.take_clipboard(); let cur=st.current_path.clone(); (c,cur) };
          if let Some((op_kind,paths))=op {
              let (s2,w2)=(s.clone(),w.clone());
              r.spawn(async move {
                  let mut errs=Vec::new();
                  for p in &paths {
                      let res=match op_kind { ClipboardOp::Copy=>repository::copy_entry(p,&cur), ClipboardOp::Cut=>repository::move_entry(p,&cur) };
                      if let Err(e)=res { errs.push(e.to_string()); }
                  }
                  if !errs.is_empty() { show_toast(&w2,&errs.join("; "),true); }
                  reload_dir(s2,w2,cur).await;
              });
          }
      }); }

    // compress
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_compress_items(move || {
          let (sources,cur)={ let st=s.lock(); (st.entries.iter().filter(|e|e.is_selected).map(|e|e.path.clone()).collect::<Vec<_>>(), st.current_path.clone()) };
          if sources.is_empty() { return; }
          let dest=cur.join("archive.zip");
          let (s2,w2)=(s.clone(),w.clone());
          r.spawn(async move {
              let d2=dest.clone();
              let res=tokio::task::spawn_blocking(move || file_browser::fs::archive::compress(&sources,&d2,|_,_,_|{})).await;
              match res { Ok(Ok(_))=>{ show_toast(&w2,"archive.zip created",false); reload_dir(s2,w2,cur).await; } _=>show_toast(&w2,"Compression failed",true) }
          });
      }); }

    // add_favorite
    { let (s,w)=(state.clone(),weak.clone());
      window.on_add_favorite(move |path| {
          let favs={ let mut st=s.lock(); st.config.toggle_favorite(path.as_str()); let _=st.config.save(); build_favorite_model(&st.config.favorites) };
          let w2=w.clone(); let _=slint::invoke_from_event_loop(move || { if let Some(win)=w2.upgrade() { win.set_favorites(favs); } });
      }); }

    // encrypt_confirm
    { let (s,r,w)=(state.clone(),rt.clone(),weak.clone());
      window.on_encrypt_confirm(move |password| {
          let (selected,cur)={ let st=s.lock(); (st.entries.iter().filter(|e|e.is_selected).cloned().collect::<Vec<_>>(), st.current_path.clone()) };
          let pw=password.to_string();
          let (s2,w2)=(s.clone(),w.clone());
          r.spawn(async move {
              for entry in &selected {
                  let path=entry.path.clone(); let pw2=pw.clone();
                  let res=tokio::task::spawn_blocking(move || {
                      if path.extension().map(|e|e=="enc").unwrap_or(false) { file_browser::security::encryption::decrypt_file(&path,&pw2) }
                      else { file_browser::security::encryption::encrypt_file(&path,&pw2) }
                  }).await;
                  if let Ok(Err(e))=res { show_toast(&w2,&e.to_string(),true); }
              }
              reload_dir(s2,w2,cur).await;
          });
      }); }

    // dialog_cancel (no-op — UI hides dialogs via property binding)
    window.on_dialog_cancel(|| {});
}
