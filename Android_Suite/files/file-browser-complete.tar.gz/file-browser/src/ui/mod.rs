// src/ui/mod.rs
pub mod bridge;
