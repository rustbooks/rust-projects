// src/lib.rs
//
// Library target — exposes all non-UI modules so integration tests in `tests/`
// can import them directly without going through the binary entry point.
//
// The Slint UI types (AppWindow, FileItem, etc.) are generated only in the
// binary target (main.rs) because they require the Slint event-loop machinery.
// Integration tests test pure logic: FS operations, encryption, search, config.
// They do NOT need the UI.

pub mod app;
pub mod core;
pub mod domain;
pub mod fs;
pub mod security;
