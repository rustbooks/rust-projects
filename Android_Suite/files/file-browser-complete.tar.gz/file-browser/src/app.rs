// src/app.rs
//
// AppState is the single source of truth shared between the Tokio async tasks
// and the UI bridge.  It is wrapped in Arc<Mutex<AppState>> (parking_lot Mutex
// for poison-free, fast locking) and never accessed directly from Slint.
//
// Navigation history is stored as a simple Vec + cursor — identical to how
// browsers implement back/forward.  This is O(1) for most operations and
// requires zero additional crates.

use crate::core::config::Config;
use crate::domain::FileEntry;
use std::path::PathBuf;

/// Clipboard operation type for copy/cut/paste.
#[derive(Debug, Clone, PartialEq)]
pub enum ClipboardOp {
    Copy,
    Cut,
}

/// The central mutable application state.
/// Never expose this directly to Slint — use the bridge layer.
pub struct AppState {
    // ── Navigation ──────────────────────────────────────────────────────────
    /// The directory currently displayed.
    pub current_path: PathBuf,

    /// Navigation history stack.  `history[cursor]` == current_path.
    history:  Vec<PathBuf>,
    cursor:   usize,

    // ── Directory contents ──────────────────────────────────────────────────
    /// The full, unfiltered list of entries in the current directory.
    /// Hidden-file filtering happens in the bridge, not here.
    pub entries: Vec<FileEntry>,

    // ── Display preferences ─────────────────────────────────────────────────
    pub show_hidden:    bool,
    pub sort_by:        String,
    pub sort_ascending: bool,

    // ── Clipboard ───────────────────────────────────────────────────────────
    pub clipboard: Option<(ClipboardOp, Vec<PathBuf>)>,

    // ── Persistent config ───────────────────────────────────────────────────
    pub config: Config,
}

impl AppState {
    /// Initialise with defaults loaded from the persisted config file.
    pub fn new() -> Self {
        let config = Config::load();
        let start = PathBuf::from(&config.start_path);
        let start = if start.is_dir() { start } else {
            dirs::home_dir().unwrap_or_else(|| PathBuf::from("/"))
        };

        Self {
            current_path:   start.clone(),
            history:        vec![start],
            cursor:         0,
            entries:        Vec::new(),
            show_hidden:    config.show_hidden_files,
            sort_by:        config.sort_by.clone(),
            sort_ascending: config.sort_ascending,
            clipboard:      None,
            config,
        }
    }

    // ── History management ────────────────────────────────────────────────────

    /// Push a new path onto the history stack (truncates forward history).
    pub fn history_push(&mut self, path: PathBuf) {
        // Don't push if it's the same as current
        if self.history.get(self.cursor) == Some(&path) {
            return;
        }
        // Truncate forward history
        self.history.truncate(self.cursor + 1);
        self.history.push(path);
        // Cap at 100 entries to avoid unbounded growth
        if self.history.len() > 100 {
            self.history.remove(0);
        } else {
            self.cursor = self.history.len() - 1;
        }
    }

    /// Move back one step.  Returns the new path or None if already at start.
    pub fn history_back(&mut self) -> Option<PathBuf> {
        if self.cursor == 0 { return None; }
        self.cursor -= 1;
        Some(self.history[self.cursor].clone())
    }

    /// Move forward one step.  Returns the new path or None if at the head.
    pub fn history_forward(&mut self) -> Option<PathBuf> {
        if self.cursor + 1 >= self.history.len() { return None; }
        self.cursor += 1;
        Some(self.history[self.cursor].clone())
    }

    pub fn can_back(&self)    -> bool { self.cursor > 0 }
    pub fn can_forward(&self) -> bool { self.cursor + 1 < self.history.len() }

    // ── Clipboard ─────────────────────────────────────────────────────────────

    pub fn copy_selected(&mut self) {
        let paths: Vec<PathBuf> = self.selected_paths();
        if !paths.is_empty() {
            self.clipboard = Some((ClipboardOp::Copy, paths));
        }
    }

    pub fn cut_selected(&mut self) {
        let paths = self.selected_paths();
        if !paths.is_empty() {
            self.clipboard = Some((ClipboardOp::Cut, paths));
        }
    }

    /// Take the clipboard contents (drains cut clipboard after use).
    pub fn take_clipboard(&mut self) -> Option<(ClipboardOp, Vec<PathBuf>)> {
        self.clipboard.take()
    }

    pub fn selected_paths(&self) -> Vec<PathBuf> {
        self.entries
            .iter()
            .filter(|e| e.is_selected)
            .map(|e| e.path.clone())
            .collect()
    }

    pub fn selected_count(&self) -> usize {
        self.entries.iter().filter(|e| e.is_selected).count()
    }

    pub fn first_selected(&self) -> Option<&FileEntry> {
        self.entries.iter().find(|e| e.is_selected)
    }

    pub fn select_all(&mut self) {
        for e in self.entries.iter_mut() {
            e.is_selected = true;
        }
    }

    pub fn deselect_all(&mut self) {
        for e in self.entries.iter_mut() {
            e.is_selected = false;
        }
    }
}

impl Default for AppState {
    fn default() -> Self { Self::new() }
}
