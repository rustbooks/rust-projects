// src/fs/watcher.rs
//
// Wraps the `notify` crate (v6) to fire reload signals when the current
// directory changes on disk.
//
// notify 6.x EventKind reference:
//   Create(_), Remove(_), Modify(DataChange | MetadataChange | Name(_) | Other), Other
//
// We react to Create, Remove, and Modify(Name) — i.e. renames — which are the
// events that change the directory listing visible to the user.

use crate::core::error::{AppError, Result};
use notify::{Config, Event, EventKind, RecommendedWatcher, RecursiveMode, Watcher};
use notify::event::ModifyKind;
use std::path::{Path, PathBuf};
use std::sync::mpsc;

pub struct FsWatcher {
    _watcher: RecommendedWatcher, // must stay alive to keep the watch active
    pub rx:   mpsc::Receiver<PathBuf>,
}

impl FsWatcher {
    /// Begin watching `path` (non-recursive).
    /// Returns a receiver that yields the containing directory whenever a
    /// meaningful filesystem event occurs.
    pub fn watch(path: &Path) -> Result<Self> {
        let (tx, rx) = mpsc::channel::<PathBuf>();
        let watch_path = path.to_owned();

        let mut watcher = RecommendedWatcher::new(
            move |result: notify::Result<Event>| {
                let Ok(event) = result else { return };

                // Filter to events that change directory content
                let interesting = matches!(
                    event.kind,
                    EventKind::Create(_) | EventKind::Remove(_)
                ) || matches!(
                    event.kind,
                    EventKind::Modify(ModifyKind::Name(_))
                );

                if interesting {
                    let dir = event
                        .paths
                        .first()
                        .and_then(|p| if p.is_dir() { Some(p.clone()) } else { p.parent().map(|x| x.to_owned()) })
                        .unwrap_or_else(|| watch_path.clone());
                    let _ = tx.send(dir);
                }
            },
            // Poll interval is used by the PollWatcher fallback on platforms
            // where native OS events are unavailable (e.g. network drives).
            Config::default(),
        )
        .map_err(|e| AppError::Other(format!("Watcher init failed: {e}")))?;

        watcher
            .watch(path, RecursiveMode::NonRecursive)
            .map_err(|e| AppError::Other(format!("Watcher attach failed: {e}")))?;

        Ok(Self { _watcher: watcher, rx })
    }

    /// Non-blocking poll for a pending change event.
    pub fn try_recv(&self) -> Option<PathBuf> {
        self.rx.try_recv().ok()
    }
}
