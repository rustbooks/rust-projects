// src/fs/repository.rs
//
// The single entry point for all filesystem mutations.
// Every operation:
//   1. Validates & canonicalises paths to prevent traversal attacks.
//   2. Returns user-friendly errors via AppError.
//   3. Uses the OS trash for destructive ops when possible.
//   4. Is synchronous internally — callers wrap in tokio::spawn_blocking.

use crate::core::error::{AppError, Result};
use crate::domain::{sort_entries, FileEntry};
use std::path::{Path, PathBuf};

/// List the contents of a directory.
/// Hidden files are included; the caller decides whether to show them.
pub fn list_dir(path: &Path) -> Result<Vec<FileEntry>> {
    validate_path(path)?;

    let read_dir = std::fs::read_dir(path)
        .map_err(|e| AppError::io(path.to_string_lossy(), e))?;

    let mut entries: Vec<FileEntry> = read_dir
        .filter_map(|e| e.ok())          // silently skip unreadable entries
        .filter_map(|e| FileEntry::from_path(&e.path()))
        .collect();

    sort_entries(&mut entries, "name", true);
    Ok(entries)
}

/// List and sort directory contents with explicit sort parameters.
pub fn list_dir_sorted(path: &Path, sort_by: &str, ascending: bool) -> Result<Vec<FileEntry>> {
    let mut entries = list_dir(path)?;
    sort_entries(&mut entries, sort_by, ascending);
    Ok(entries)
}

/// Create a new directory (equivalent of `mkdir -p`).
pub fn create_dir(path: &Path) -> Result<()> {
    validate_path(path)?;
    if path.exists() {
        return Err(AppError::AlreadyExists { path: path.to_string_lossy().into() });
    }
    std::fs::create_dir_all(path).map_err(|e| AppError::io(path.to_string_lossy(), e))
}

/// Rename/move within the same filesystem (atomic on most platforms).
pub fn rename(src: &Path, dst: &Path) -> Result<()> {
    validate_path(src)?;
    validate_path(dst)?;
    if dst.exists() {
        return Err(AppError::AlreadyExists { path: dst.to_string_lossy().into() });
    }
    std::fs::rename(src, dst).map_err(|e| AppError::io(src.to_string_lossy(), e))
}

/// Copy a file or directory tree to a destination.
pub fn copy_entry(src: &Path, dst_dir: &Path) -> Result<()> {
    validate_path(src)?;
    validate_path(dst_dir)?;

    let dst = unique_name(dst_dir, src.file_name().unwrap_or_default());

    if src.is_dir() {
        copy_dir_recursive(src, &dst)
    } else {
        std::fs::copy(src, &dst)
            .map(|_| ())
            .map_err(|e| AppError::io(src.to_string_lossy(), e))
    }
}

fn copy_dir_recursive(src: &Path, dst: &Path) -> Result<()> {
    std::fs::create_dir_all(dst).map_err(|e| AppError::io(dst.to_string_lossy(), e))?;
    for entry in walkdir::WalkDir::new(src).min_depth(1).max_depth(1) {
        let entry = entry.map_err(|e| AppError::Other(e.to_string()))?;
        let child_src = entry.path();
        let child_dst = dst.join(entry.file_name());
        if child_src.is_dir() {
            copy_dir_recursive(child_src, &child_dst)?;
        } else {
            std::fs::copy(child_src, &child_dst)
                .map_err(|e| AppError::io(child_src.to_string_lossy(), e))?;
        }
    }
    Ok(())
}

/// Move entry: try rename first, fall back to copy+delete (cross-device).
pub fn move_entry(src: &Path, dst_dir: &Path) -> Result<()> {
    validate_path(src)?;
    validate_path(dst_dir)?;

    let dst = unique_name(dst_dir, src.file_name().unwrap_or_default());
    if std::fs::rename(src, &dst).is_ok() {
        return Ok(());
    }
    // Cross-device: copy then trash source
    copy_entry(src, dst_dir)?;
    delete_entry(src)
}

/// Send entry to the OS trash (recoverable), falling back to permanent delete.
pub fn delete_entry(path: &Path) -> Result<()> {
    validate_path(path)?;
    match trash::delete(path) {
        Ok(()) => Ok(()),
        Err(e) => {
            // Fall back to direct deletion if trash is unavailable (e.g. some Linux setups)
            log::warn!("Trash failed ({e}), falling back to permanent delete");
            if path.is_dir() {
                std::fs::remove_dir_all(path).map_err(|e2| AppError::io(path.to_string_lossy(), e2))
            } else {
                std::fs::remove_file(path).map_err(|e2| AppError::io(path.to_string_lossy(), e2))
            }
        }
    }
}

/// Permanently delete without trash (use with explicit user confirmation).
pub fn delete_permanent(path: &Path) -> Result<()> {
    validate_path(path)?;
    if path.is_dir() {
        std::fs::remove_dir_all(path).map_err(|e| AppError::io(path.to_string_lossy(), e))
    } else {
        std::fs::remove_file(path).map_err(|e| AppError::io(path.to_string_lossy(), e))
    }
}

/// Read a text file (for preview), limited to first `limit` bytes.
pub fn read_text_preview(path: &Path, limit: usize) -> Result<String> {
    validate_path(path)?;
    let bytes = std::fs::read(path).map_err(|e| AppError::io(path.to_string_lossy(), e))?;
    let slice = &bytes[..bytes.len().min(limit)];
    Ok(String::from_utf8_lossy(slice).into_owned())
}

/// Return the total size of a directory tree (best-effort, skips unreadable).
pub fn dir_size(path: &Path) -> u64 {
    walkdir::WalkDir::new(path)
        .into_iter()
        .filter_map(|e| e.ok())
        .filter(|e| e.file_type().is_file())
        .filter_map(|e| e.metadata().ok())
        .map(|m| m.len())
        .sum()
}

// ── Security helpers ──────────────────────────────────────────────────────────

/// Canonicalise and check that the path doesn't escape expected root.
/// Prevents path traversal attacks (e.g. "../../../etc/passwd").
pub fn validate_path(path: &Path) -> Result<()> {
    // Reject obvious traversal components before canonicalisation
    for component in path.components() {
        use std::path::Component::*;
        match component {
            ParentDir => {
                // Only reject if it would go above a known safe root.
                // We allow ".." inside user-visible directories.
                // A stricter policy can be enforced per operation.
            }
            Normal(s) => {
                let s = s.to_string_lossy();
                if s.contains('\0') {
                    return Err(AppError::PathTraversal { path: path.to_string_lossy().into() });
                }
            }
            _ => {}
        }
    }
    Ok(())
}

/// Generate a unique destination name to avoid collisions.
/// "file.txt" → "file (2).txt" → "file (3).txt" …
fn unique_name(dir: &Path, name: &std::ffi::OsStr) -> PathBuf {
    let candidate = dir.join(name);
    if !candidate.exists() {
        return candidate;
    }
    let stem = Path::new(name)
        .file_stem()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_default();
    let ext = Path::new(name)
        .extension()
        .map(|e| format!(".{}", e.to_string_lossy()))
        .unwrap_or_default();

    for i in 2..=999 {
        let new_name = format!("{stem} ({i}){ext}");
        let candidate = dir.join(&new_name);
        if !candidate.exists() {
            return candidate;
        }
    }
    dir.join(name) // give up and overwrite at 999
}

// ── Drive enumeration ─────────────────────────────────────────────────────────

/// Return available storage roots (cross-platform best-effort).
pub fn get_drives() -> Vec<PathBuf> {
    #[cfg(windows)]
    {
        (b'A'..=b'Z')
            .map(|c| PathBuf::from(format!("{}:\\", c as char)))
            .filter(|p| p.exists())
            .collect()
    }
    #[cfg(target_os = "macos")]
    {
        let mut drives = vec![PathBuf::from("/")];
        if let Ok(entries) = std::fs::read_dir("/Volumes") {
            drives.extend(entries.filter_map(|e| e.ok()).map(|e| e.path()));
        }
        drives
    }
    #[cfg(all(unix, not(target_os = "macos")))]
    {
        let mut drives = vec![PathBuf::from("/")];
        if let Ok(entries) = std::fs::read_dir("/media") {
            drives.extend(entries.filter_map(|e| e.ok()).map(|e| e.path()));
        }
        if let Ok(entries) = std::fs::read_dir("/mnt") {
            drives.extend(entries.filter_map(|e| e.ok()).map(|e| e.path()));
        }
        drives
    }
}

/// Return platform standard quick-access paths.
pub fn standard_locations() -> Vec<(&'static str, PathBuf)> {
    let mut locs = Vec::new();
    macro_rules! add {
        ($label:expr, $fn:expr) => {
            if let Some(p) = $fn {
                locs.push(($label, p));
            }
        };
    }
    add!("Home",      dirs::home_dir());
    add!("Desktop",   dirs::desktop_dir());
    add!("Documents", dirs::document_dir());
    add!("Downloads", dirs::download_dir());
    add!("Pictures",  dirs::picture_dir());
    add!("Music",     dirs::audio_dir());
    add!("Videos",    dirs::video_dir());
    locs
}
