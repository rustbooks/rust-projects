// src/fs/search.rs
//
// Parallel file search using Rayon + WalkDir.
// Search is split into two phases:
//   1. Name/metadata filter  (fast, always runs)
//   2. Content search        (slow, opt-in via SearchQuery::content_query)

use crate::core::error::{AppError, Result};
use crate::domain::FileEntry;
use rayon::prelude::*;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

/// Everything the user can filter on in the search UI.
#[derive(Debug, Clone, Default)]
pub struct SearchQuery {
    /// Substring match on file name (case-insensitive)
    pub name: String,
    /// Optional content search (plain text files only)
    pub content: Option<String>,
    /// Filter by file extension (e.g. "rs", "pdf")
    pub extension: Option<String>,
    /// Minimum size in bytes
    pub min_size: Option<u64>,
    /// Maximum size in bytes
    pub max_size: Option<u64>,
    /// Modified within last N seconds
    pub modified_within_secs: Option<u64>,
    /// Include hidden files in results
    pub include_hidden: bool,
}

impl SearchQuery {
    pub fn from_name(name: impl Into<String>) -> Self {
        Self { name: name.into(), ..Default::default() }
    }
    pub fn is_empty(&self) -> bool {
        self.name.is_empty()
            && self.content.is_none()
            && self.extension.is_none()
            && self.min_size.is_none()
            && self.max_size.is_none()
            && self.modified_within_secs.is_none()
    }
}

/// Run a search synchronously (call from tokio::spawn_blocking).
/// Returns up to `limit` results, sorted by name.
/// Pass a cancel token to abort early.
pub fn search_dir(
    root: &Path,
    query: &SearchQuery,
    limit: usize,
    cancel: Arc<AtomicBool>,
) -> Result<Vec<FileEntry>> {
    if query.is_empty() {
        return Ok(Vec::new());
    }

    let name_lower = query.name.to_lowercase();
    let ext_lower  = query.extension.as_deref().map(str::to_lowercase);
    let content_q  = query.content.as_deref().map(str::to_lowercase);
    let now        = std::time::SystemTime::now();

    // Collect paths in parallel (WalkDir itself is single-threaded)
    let paths: Vec<PathBuf> = walkdir::WalkDir::new(root)
        .follow_links(false)
        .into_iter()
        .take_while(|_| !cancel.load(Ordering::Relaxed))
        .filter_map(|e| e.ok())
        .map(|e| e.into_path())
        .filter(|p| p.is_file())
        .collect();

    // Apply filters in parallel using Rayon, then truncate to limit
    let mut results: Vec<FileEntry> = paths
        .par_iter()
        .filter(|p| {
            if cancel.load(Ordering::Relaxed) { return false; }

            let name = p.file_name()
                .map(|n| n.to_string_lossy().to_lowercase())
                .unwrap_or_default();

            // Hidden file filter
            if !query.include_hidden && name.starts_with('.') {
                return false;
            }

            // Name substring match
            if !name_lower.is_empty() && !name.contains(&name_lower) {
                return false;
            }

            // Extension filter
            if let Some(ext) = &ext_lower {
                let file_ext = p.extension()
                    .map(|e| e.to_string_lossy().to_lowercase())
                    .unwrap_or_default();
                if file_ext.as_str() != ext.as_str() {
                    return false;
                }
            }

            // Size filters
            if query.min_size.is_some() || query.max_size.is_some() {
                let size = p.metadata().map(|m| m.len()).unwrap_or(0);
                if let Some(min) = query.min_size { if size < min { return false; } }
                if let Some(max) = query.max_size { if size > max { return false; } }
            }

            // Modified date filter
            if let Some(secs) = query.modified_within_secs {
                if let Ok(modified) = p.metadata().and_then(|m| m.modified()) {
                    if let Ok(elapsed) = now.duration_since(modified) {
                        if elapsed.as_secs() > secs { return false; }
                    }
                }
            }

            true
        })
        .filter(|p| {
            // Content search (expensive — only on text-like files)
            if let Some(query_str) = &content_q {
                if let Ok(text) = std::fs::read_to_string(p) {
                    return text.to_lowercase().contains(query_str.as_str());
                }
                return false; // binary / unreadable
            }
            true
        })
        .filter_map(|p| FileEntry::from_path(p))
        .collect();

    // Truncate to limit after collecting (rayon has no streaming take)
    results.truncate(limit);

    if cancel.load(Ordering::Relaxed) {
        return Err(AppError::SearchCancelled);
    }

    results.sort_by(|a, b| a.name.to_lowercase().cmp(&b.name.to_lowercase()));
    Ok(results)
}
