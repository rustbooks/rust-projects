// src/fs/archive.rs
//
// ZIP archive support: compress selected files/dirs, extract existing archives.
// Uses the `zip` crate (v2) with Deflate compression — maximum compatibility,
// minimal binary footprint.
//
// FUTURE: Add zstd / 7-Zip via feature flags for better compression ratios.

use crate::core::error::{AppError, Result};
use std::fs::File;
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use zip::write::FileOptions;
use zip::{ZipArchive, ZipWriter, CompressionMethod};

/// Compress multiple `sources` into a single ZIP at `dest`.
/// Directories are added recursively.
///
/// `progress(current_name, files_done, total_files)` is called before each file.
pub fn compress<F>(sources: &[PathBuf], dest: &Path, progress: F) -> Result<()>
where
    F: Fn(&str, usize, usize),
{
    let file = File::create(dest).map_err(|e| AppError::io(dest.to_string_lossy(), e))?;
    let mut zip = ZipWriter::new(file);

    let options: FileOptions<()> = FileOptions::default()
        .compression_method(CompressionMethod::Deflated)
        .unix_permissions(0o644);

    // Collect all paths upfront for accurate progress reporting
    let all_files: Vec<PathBuf> = sources.iter().flat_map(|s| collect_paths(s)).collect();
    let total = all_files.len();

    for (i, path) in all_files.iter().enumerate() {
        let display_name = path
            .file_name()
            .map(|n| n.to_string_lossy().into_owned())
            .unwrap_or_default();
        progress(&display_name, i, total);

        let archive_name = relative_archive_name(sources, path);

        if path.is_dir() {
            zip.add_directory(&archive_name, options)
                .map_err(|e| AppError::Archive(e.to_string()))?;
        } else {
            zip.start_file(&archive_name, options)
                .map_err(|e| AppError::Archive(e.to_string()))?;

            let mut f = File::open(path).map_err(|e| AppError::io(path.to_string_lossy(), e))?;
            let mut buf = Vec::new();
            f.read_to_end(&mut buf)
                .map_err(|e| AppError::io(path.to_string_lossy(), e))?;
            zip.write_all(&buf)
                .map_err(|e| AppError::Archive(e.to_string()))?;
        }
    }

    zip.finish().map_err(|e| AppError::Archive(e.to_string()))?;
    Ok(())
}

/// Extract a ZIP archive to `dest_dir`.
/// Returns a list of extracted file paths.
pub fn extract(archive: &Path, dest_dir: &Path) -> Result<Vec<PathBuf>> {
    std::fs::create_dir_all(dest_dir)
        .map_err(|e| AppError::io(dest_dir.to_string_lossy(), e))?;

    let file = File::open(archive).map_err(|e| AppError::io(archive.to_string_lossy(), e))?;
    let mut zip = ZipArchive::new(file).map_err(|e| AppError::Archive(e.to_string()))?;

    let mut extracted = Vec::new();

    for i in 0..zip.len() {
        let mut entry = zip.by_index(i).map_err(|e| AppError::Archive(e.to_string()))?;

        // Security: sanitise entry name to prevent zip-slip attacks
        let safe_name = sanitize_zip_name(entry.name());
        if safe_name.is_empty() {
            continue;
        }
        let out_path = dest_dir.join(&safe_name);

        if entry.is_dir() {
            std::fs::create_dir_all(&out_path)
                .map_err(|e| AppError::io(out_path.to_string_lossy(), e))?;
        } else {
            if let Some(parent) = out_path.parent() {
                std::fs::create_dir_all(parent)
                    .map_err(|e| AppError::io(parent.to_string_lossy(), e))?;
            }
            let mut out = File::create(&out_path)
                .map_err(|e| AppError::io(out_path.to_string_lossy(), e))?;
            std::io::copy(&mut entry, &mut out)
                .map_err(|e| AppError::io(out_path.to_string_lossy(), e))?;
            extracted.push(out_path);
        }
    }

    Ok(extracted)
}

/// List the contents of a ZIP archive without extracting.
pub fn list_archive(archive: &Path) -> Result<Vec<String>> {
    let file = File::open(archive).map_err(|e| AppError::io(archive.to_string_lossy(), e))?;
    let mut zip = ZipArchive::new(file).map_err(|e| AppError::Archive(e.to_string()))?;
    let names = (0..zip.len())
        .filter_map(|i| zip.by_index(i).ok())
        .map(|e| e.name().to_owned())
        .collect();
    Ok(names)
}

// ── Internal helpers ──────────────────────────────────────────────────────────

/// Recursively collect all filesystem paths under `root`.
fn collect_paths(root: &Path) -> Vec<PathBuf> {
    if root.is_file() {
        return vec![root.to_owned()];
    }
    walkdir::WalkDir::new(root)
        .into_iter()
        .filter_map(|e| e.ok())
        .map(|e| e.into_path())
        .collect()
}

/// Compute a relative path suitable for use as the in-archive filename.
/// Strips the parent directory of each source so archives are self-contained.
fn relative_archive_name(sources: &[PathBuf], path: &Path) -> String {
    for src in sources {
        let base = src.parent().unwrap_or(src);
        if let Ok(rel) = path.strip_prefix(base) {
            return rel.to_string_lossy().replace('\\', "/");
        }
    }
    path.file_name()
        .map(|n| n.to_string_lossy().into_owned())
        .unwrap_or_default()
}

/// Strip absolute paths and traversal components from a ZIP entry name.
/// This prevents "zip-slip" attacks where archive entries escape the
/// destination directory via `../` sequences.
pub fn sanitize_zip_name(name: &str) -> String {
    // Replace backslashes (Windows paths inside ZIP) with forward slashes
    let normalized = name.replace('\\', "/");
    // Filter: keep only Normal (non-separator, non-parent) components
    Path::new(&normalized)
        .components()
        .filter(|c| matches!(c, std::path::Component::Normal(_)))
        .collect::<PathBuf>()
        .to_string_lossy()
        .into_owned()
}
