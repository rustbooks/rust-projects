// src/fs/mod.rs
pub mod archive;
pub mod repository;
pub mod search;
pub mod watcher;
