// src/domain/mod.rs
pub mod file_entry;
pub use file_entry::{FileCategory, FileEntry, EntryKind, categorize, sort_entries};
