// src/domain/file_entry.rs
//
// The canonical domain model for a single filesystem item.
// This is platform-independent and never touches the UI directly.
// The UI bridge (src/ui/bridge.rs) converts FileEntry → Slint struct.

use chrono::{DateTime, Local};
use humansize::{format_size, DECIMAL};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use std::time::SystemTime;

/// What kind of filesystem object this entry represents.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum EntryKind {
    Directory,
    File,
    Symlink { target: Option<PathBuf> },
}

/// High-level file-type category used to pick icons and preview strategies.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum FileCategory {
    Folder,
    Image,
    Video,
    Audio,
    Document,   // PDF, Word, etc.
    Code,       // .rs, .py, .js, …
    Archive,    // zip, tar, 7z, …
    Text,       // plain text
    Executable,
    Other,
}

/// A fully-resolved filesystem entry with cached metadata.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileEntry {
    pub path: PathBuf,
    pub name: String,
    pub kind: EntryKind,
    pub category: FileCategory,
    pub size: u64,          // bytes (0 for directories)
    pub modified: SystemTime,
    pub is_hidden: bool,
    pub is_readonly: bool,
    pub extension: String,  // lowercase, without dot
    pub is_encrypted: bool, // our own .enc marker
    pub is_selected: bool,  // transient UI state
}

impl FileEntry {
    /// Build a `FileEntry` from a directory entry.
    /// Never panics — permission errors surface as sentinel values.
    pub fn from_path(path: &Path) -> Option<Self> {
        let metadata = match path.symlink_metadata() {
            Ok(m) => m,
            Err(_) => return None,
        };

        let name = path.file_name()?.to_string_lossy().into_owned();
        let extension = path
            .extension()
            .map(|e| e.to_string_lossy().to_ascii_lowercase())
            .unwrap_or_default();

        let kind = if metadata.is_symlink() {
            EntryKind::Symlink {
                target: std::fs::read_link(path).ok(),
            }
        } else if metadata.is_dir() {
            EntryKind::Directory
        } else {
            EntryKind::File
        };

        let size = if metadata.is_dir() { 0 } else { metadata.len() };
        let modified = metadata.modified().unwrap_or(SystemTime::UNIX_EPOCH);

        #[cfg(unix)]
        let is_readonly = {
            use std::os::unix::fs::PermissionsExt;
            metadata.permissions().mode() & 0o200 == 0
        };
        #[cfg(not(unix))]
        let is_readonly = metadata.permissions().readonly();

        let is_hidden = is_hidden_entry(&name, path);
        let is_encrypted = extension == "enc";
        let category = categorize(&kind, &extension);

        Some(Self {
            path: path.to_owned(),
            name,
            kind,
            category,
            size,
            modified,
            is_hidden,
            is_readonly,
            extension,
            is_encrypted,
            is_selected: false,
        })
    }

    /// Human-readable file size string.
    pub fn size_display(&self) -> String {
        if matches!(self.kind, EntryKind::Directory) {
            return String::new();
        }
        format_size(self.size, DECIMAL)
    }

    /// Formatted modification date.
    pub fn modified_display(&self) -> String {
        let dt: DateTime<Local> = self.modified.into();
        dt.format("%Y-%m-%d  %H:%M").to_string()
    }

    /// Icon character for the entry type (used in UI text icons).
    pub fn icon(&self) -> &'static str {
        match &self.category {
            FileCategory::Folder    => "📁",
            FileCategory::Image     => "🖼",
            FileCategory::Video     => "🎬",
            FileCategory::Audio     => "🎵",
            FileCategory::Document  => "📄",
            FileCategory::Code      => "💻",
            FileCategory::Archive   => "📦",
            FileCategory::Text      => "📝",
            FileCategory::Executable=> "⚙",
            FileCategory::Other     => "📎",
        }
    }

    pub fn is_dir(&self) -> bool {
        matches!(self.kind, EntryKind::Directory)
    }

    pub fn path_str(&self) -> String {
        self.path.to_string_lossy().into_owned()
    }
}

/// Map extension → FileCategory.
/// Kept as a pure function for easy unit testing.
pub fn categorize(kind: &EntryKind, ext: &str) -> FileCategory {
    if matches!(kind, EntryKind::Directory) {
        return FileCategory::Folder;
    }
    match ext {
        "jpg" | "jpeg" | "png" | "gif" | "bmp" | "webp" | "svg" | "heic" | "avif"
            => FileCategory::Image,
        "mp4" | "mkv" | "mov" | "avi" | "webm" | "flv" | "m4v"
            => FileCategory::Video,
        "mp3" | "flac" | "ogg" | "wav" | "aac" | "m4a" | "opus"
            => FileCategory::Audio,
        "pdf" | "doc" | "docx" | "odt" | "xls" | "xlsx" | "ppt" | "pptx"
            => FileCategory::Document,
        "rs" | "py" | "js" | "ts" | "go" | "c" | "cpp" | "h" | "java"
        | "kt" | "swift" | "rb" | "php" | "cs" | "html" | "css" | "json"
        | "yaml" | "toml" | "xml" | "sh" | "bash" | "zsh" | "fish" | "lua"
            => FileCategory::Code,
        "zip" | "tar" | "gz" | "bz2" | "xz" | "7z" | "rar" | "zst"
            => FileCategory::Archive,
        "txt" | "md" | "rst" | "log" | "csv" | "tsv"
            => FileCategory::Text,
        #[cfg(unix)]
        "" | "run" | "sh" | "bin"
            => FileCategory::Executable,
        #[cfg(windows)]
        "exe" | "msi" | "bat" | "cmd" | "ps1"
            => FileCategory::Executable,
        _ => FileCategory::Other,
    }
}

/// Check if an entry should be considered hidden.
/// On Unix: leading dot.  On Windows: FILE_ATTRIBUTE_HIDDEN.
fn is_hidden_entry(name: &str, path: &Path) -> bool {
    if name.starts_with('.') {
        return true;
    }
    #[cfg(windows)]
    {
        use std::os::windows::fs::MetadataExt;
        if let Ok(meta) = path.metadata() {
            const FILE_ATTRIBUTE_HIDDEN: u32 = 0x2;
            return meta.file_attributes() & FILE_ATTRIBUTE_HIDDEN != 0;
        }
    }
    false
}

/// Sort a slice of FileEntry by the given key.
/// Directories always sort before files (natural file-manager behaviour).
pub fn sort_entries(entries: &mut Vec<FileEntry>, by: &str, ascending: bool) {
    entries.sort_by(|a, b| {
        // Directories first
        let dir_cmp = b.is_dir().cmp(&a.is_dir());
        if dir_cmp != std::cmp::Ordering::Equal {
            return dir_cmp;
        }
        let ord = match by {
            "size"  => a.size.cmp(&b.size),
            "date"  => a.modified.cmp(&b.modified),
            "type"  => a.extension.cmp(&b.extension),
            _       => a.name.to_lowercase().cmp(&b.name.to_lowercase()),
        };
        if ascending { ord } else { ord.reverse() }
    });
}
