// src/security/encryption.rs
//
// AES-256-GCM authenticated encryption for individual files.
//
// Design decisions:
//  • AES-256-GCM: authenticated encryption = confidentiality + integrity.
//    Any tampering with the ciphertext causes decryption to fail loudly.
//  • PBKDF2-SHA256 with 600,000 iterations (OWASP 2023 recommendation).
//  • Random 16-byte salt per file — same password, different ciphertext.
//  • Random 12-byte nonce per file — GCM mandates nonce uniqueness.
//  • Encrypted file format: [MAGIC 4B][SALT 16B][NONCE 12B][CIPHERTEXT+TAG]
//
// The .enc extension is appended/stripped to signal encrypted state.
// FUTURE: Consider age (https://age-encryption.org) for key-based encryption.

use aes_gcm::{
    aead::{Aead, KeyInit},
    Aes256Gcm, Key, Nonce,
};
use rand::rngs::OsRng;
use crate::core::error::{AppError, Result};
use rand::RngCore;
use sha2::Sha256;
use std::path::{Path, PathBuf};

const MAGIC: &[u8; 4] = b"FBRC"; // File Browser RC (our marker)
const SALT_LEN: usize  = 16;
const NONCE_LEN: usize = 12;
const PBKDF2_ITERS: u32 = 600_000;

/// Encrypt `src` with `password`.  Writes `src.enc`, returns the new path.
/// The original file is NOT deleted — the caller decides.
pub fn encrypt_file(src: &Path, password: &str) -> Result<PathBuf> {
    let plaintext = std::fs::read(src)
        .map_err(|e| AppError::io(src.to_string_lossy(), e))?;

    // Derive key from password
    let mut salt  = [0u8; SALT_LEN];
    let mut nonce_bytes = [0u8; NONCE_LEN];
    OsRng.fill_bytes(&mut salt);
    OsRng.fill_bytes(&mut nonce_bytes);

    let key = derive_key(password, &salt);
    let cipher = Aes256Gcm::new(Key::<Aes256Gcm>::from_slice(&key));
    let nonce  = Nonce::from_slice(&nonce_bytes);

    let ciphertext = cipher
        .encrypt(nonce, plaintext.as_slice())
        .map_err(|_| AppError::Encryption("AES-GCM encryption failed".into()))?;

    // Assemble file: MAGIC | SALT | NONCE | CIPHERTEXT
    let mut output = Vec::with_capacity(4 + SALT_LEN + NONCE_LEN + ciphertext.len());
    output.extend_from_slice(MAGIC);
    output.extend_from_slice(&salt);
    output.extend_from_slice(&nonce_bytes);
    output.extend_from_slice(&ciphertext);

    let dest = src.with_extension(format!(
        "{}.enc",
        src.extension().map(|e| e.to_string_lossy()).unwrap_or_default()
    ));
    std::fs::write(&dest, &output)
        .map_err(|e| AppError::io(dest.to_string_lossy(), e))?;

    Ok(dest)
}

/// Decrypt an `.enc` file produced by `encrypt_file`.
/// Returns the path of the decrypted output.
pub fn decrypt_file(src: &Path, password: &str) -> Result<PathBuf> {
    let data = std::fs::read(src)
        .map_err(|e| AppError::io(src.to_string_lossy(), e))?;

    // Validate magic bytes
    if data.len() < 4 + SALT_LEN + NONCE_LEN || &data[..4] != MAGIC {
        return Err(AppError::DecryptionFailed);
    }

    let salt        = &data[4..4 + SALT_LEN];
    let nonce_bytes = &data[4 + SALT_LEN..4 + SALT_LEN + NONCE_LEN];
    let ciphertext  = &data[4 + SALT_LEN + NONCE_LEN..];

    let key = derive_key(password, salt);
    let cipher = Aes256Gcm::new(Key::<Aes256Gcm>::from_slice(&key));
    let nonce  = Nonce::from_slice(nonce_bytes);

    let plaintext = cipher
        .decrypt(nonce, ciphertext)
        .map_err(|_| AppError::DecryptionFailed)?;

    // Strip the .enc extension to get the original name
    let dest = strip_enc_extension(src);
    std::fs::write(&dest, &plaintext)
        .map_err(|e| AppError::io(dest.to_string_lossy(), e))?;

    Ok(dest)
}

/// Derive a 32-byte AES-256 key from a password + salt using PBKDF2-SHA256.
fn derive_key(password: &str, salt: &[u8]) -> [u8; 32] {
    let mut key = [0u8; 32];
    pbkdf2::pbkdf2_hmac::<Sha256>(
        password.as_bytes(),
        salt,
        PBKDF2_ITERS,
        &mut key,
    );
    key
}

fn strip_enc_extension(path: &Path) -> PathBuf {
    // "photo.jpg.enc" → "photo.jpg"
    // "document.enc"  → "document"
    let s = path.to_string_lossy();
    if let Some(stripped) = s.strip_suffix(".enc") {
        PathBuf::from(stripped)
    } else {
        path.with_extension("")
    }
}
