// src/security/mod.rs
pub mod encryption;
