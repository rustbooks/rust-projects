// src/core/config.rs
//
// Persistent user preferences stored as JSON in the platform config directory.
// Using serde + serde_json (already a transitive dep of many crates) keeps
// the footprint minimal vs embedding a full DB or TOML parser.

use crate::core::error::{AppError, Result};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

/// All user-tuneable settings.  Adding new fields with `#[serde(default)]`
/// preserves backward compatibility — old config files just get new defaults.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    // ── Navigation ──────────────────────────────────────────────────────────
    #[serde(default = "default_start_path")]
    pub start_path: String,

    #[serde(default)]
    pub show_hidden_files: bool,

    // ── Appearance ──────────────────────────────────────────────────────────
    #[serde(default = "default_true")]
    pub dark_mode: bool,

    #[serde(default = "default_view_mode")]
    pub view_mode: String, // "grid" | "list"

    #[serde(default = "default_sort")]
    pub sort_by: String, // "name" | "size" | "date" | "type"

    #[serde(default)]
    pub sort_ascending: bool,

    // ── Bookmarks ──────────────────────────────────────────────────────────
    #[serde(default)]
    pub favorites: Vec<String>,

    // ── Recent files (last 50) ─────────────────────────────────────────────
    #[serde(default)]
    pub recent_paths: Vec<String>,

    // ── Window geometry ────────────────────────────────────────────────────
    #[serde(default = "default_width")]
    pub window_width: u32,

    #[serde(default = "default_height")]
    pub window_height: u32,

    // ── Security ───────────────────────────────────────────────────────────
    #[serde(default)]
    pub confirm_delete: bool,

    #[serde(default = "default_true")]
    pub use_trash: bool, // safe delete via OS trash

    // ── Sidebar width ──────────────────────────────────────────────────────
    #[serde(default = "default_sidebar")]
    pub sidebar_width: f32,
}

// ── Defaults ─────────────────────────────────────────────────────────────────
fn default_start_path() -> String {
    dirs::home_dir()
        .unwrap_or_else(|| PathBuf::from("/"))
        .to_string_lossy()
        .into_owned()
}
fn default_true() -> bool { true }
fn default_view_mode() -> String { "grid".into() }
fn default_sort() -> String { "name".into() }
fn default_width() -> u32 { 1200 }
fn default_height() -> u32 { 800 }
fn default_sidebar() -> f32 { 220.0 }

impl Default for Config {
    fn default() -> Self {
        serde_json::from_str("{}").expect("default config is valid JSON")
    }
}

impl Config {
    /// Locate the config file: `$CONFIG_DIR/file-browser/config.json`
    pub fn config_path() -> PathBuf {
        dirs::config_dir()
            .unwrap_or_else(|| PathBuf::from("."))
            .join("file-browser")
            .join("config.json")
    }

    /// Load from disk, falling back to defaults on any error.
    pub fn load() -> Self {
        let path = Self::config_path();
        let data = match std::fs::read_to_string(&path) {
            Ok(d) => d,
            Err(_) => return Self::default(),
        };
        serde_json::from_str(&data).unwrap_or_default()
    }

    /// Persist to disk atomically (write to temp, then rename).
    pub fn save(&self) -> Result<()> {
        let path = Self::config_path();
        if let Some(dir) = path.parent() {
            std::fs::create_dir_all(dir)
                .map_err(|e| AppError::Config(format!("Cannot create config dir: {e}")))?;
        }
        let json = serde_json::to_string_pretty(self)
            .map_err(|e| AppError::Config(e.to_string()))?;

        // Atomic write: write to temp file then rename
        let tmp = path.with_extension("tmp");
        std::fs::write(&tmp, &json)
            .map_err(|e| AppError::Config(e.to_string()))?;
        std::fs::rename(&tmp, &path)
            .map_err(|e| AppError::Config(e.to_string()))?;
        Ok(())
    }

    /// Add a path to recents, keeping only the last 50.
    pub fn add_recent(&mut self, path: impl Into<String>) {
        let p = path.into();
        self.recent_paths.retain(|x| x != &p);
        self.recent_paths.insert(0, p);
        self.recent_paths.truncate(50);
    }

    /// Toggle a path in favorites.
    pub fn toggle_favorite(&mut self, path: impl Into<String>) {
        let p = path.into();
        if let Some(i) = self.favorites.iter().position(|x| x == &p) {
            self.favorites.remove(i);
        } else {
            self.favorites.push(p);
        }
    }

    pub fn is_favorite(&self, path: &str) -> bool {
        self.favorites.iter().any(|f| f == path)
    }
}
