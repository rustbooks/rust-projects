// src/core/mod.rs
pub mod config;
pub mod error;
