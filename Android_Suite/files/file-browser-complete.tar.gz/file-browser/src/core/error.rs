// src/core/error.rs
//
// Centralised error taxonomy.  thiserror generates Display + Error impls
// automatically, keeping this DRY.  Every variant maps to a user-visible
// message so the UI layer never needs to pattern-match on opaque strings.

use thiserror::Error;

#[derive(Debug, Error)]
pub enum AppError {
    // ── File-system errors ────────────────────────────────────────────────────
    #[error("Permission denied: {path}")]
    PermissionDenied { path: String },

    #[error("Path does not exist: {path}")]
    NotFound { path: String },

    #[error("Path traversal attempt detected: {path}")]
    PathTraversal { path: String },

    #[error("File already exists: {path}")]
    AlreadyExists { path: String },

    #[error("I/O error on '{path}': {source}")]
    Io {
        path: String,
        #[source]
        source: std::io::Error,
    },

    // ── Archive errors ────────────────────────────────────────────────────────
    #[error("Archive error: {0}")]
    Archive(String),

    // ── Encryption errors ─────────────────────────────────────────────────────
    #[error("Encryption failed: {0}")]
    Encryption(String),

    #[error("Decryption failed — wrong password or corrupted file")]
    DecryptionFailed,

    // ── Configuration errors ──────────────────────────────────────────────────
    #[error("Config error: {0}")]
    Config(String),

    // ── Search errors ─────────────────────────────────────────────────────────
    #[error("Search cancelled")]
    SearchCancelled,

    // ── Generic catch-all ─────────────────────────────────────────────────────
    #[error("{0}")]
    Other(String),
}

// Convenient conversion from std::io::Error with a path annotation
impl AppError {
    pub fn io(path: impl Into<String>, e: std::io::Error) -> Self {
        use std::io::ErrorKind::*;
        match e.kind() {
            PermissionDenied => AppError::PermissionDenied { path: path.into() },
            NotFound => AppError::NotFound { path: path.into() },
            AlreadyExists => AppError::AlreadyExists { path: path.into() },
            _ => AppError::Io { path: path.into(), source: e },
        }
    }
}

pub type Result<T> = std::result::Result<T, AppError>;
