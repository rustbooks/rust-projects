// tests/integration_tests.rs
//
// Integration tests for File Browser.
// Run with: cargo test
// Run with output: cargo test -- --nocapture

use std::path::PathBuf;
use tempfile::TempDir;

// ── Helpers ───────────────────────────────────────────────────────────────────

fn temp_dir() -> TempDir {
    tempfile::tempdir().expect("Cannot create temp dir")
}

fn make_file(dir: &std::path::Path, name: &str, content: &[u8]) -> PathBuf {
    let path = dir.join(name);
    std::fs::write(&path, content).expect("write");
    path
}

fn make_dir(parent: &std::path::Path, name: &str) -> PathBuf {
    let path = parent.join(name);
    std::fs::create_dir(&path).expect("mkdir");
    path
}

// ── Domain tests ─────────────────────────────────────────────────────────────

#[cfg(test)]
mod domain_tests {
    use super::*;
    use file_browser::domain::file_entry::*;

    #[test]
    fn categorise_image_extensions() {
        for ext in &["jpg", "jpeg", "png", "gif", "webp", "svg"] {
            assert_eq!(
                categorize(&EntryKind::File, ext),
                FileCategory::Image,
                "Expected Image for .{ext}"
            );
        }
    }

    #[test]
    fn categorise_code_extensions() {
        for ext in &["rs", "py", "js", "ts", "go", "c", "cpp"] {
            assert_eq!(
                categorize(&EntryKind::File, ext),
                FileCategory::Code,
                "Expected Code for .{ext}"
            );
        }
    }

    #[test]
    fn categorise_archive_extensions() {
        for ext in &["zip", "tar", "gz", "bz2", "7z"] {
            assert_eq!(
                categorize(&EntryKind::File, ext),
                FileCategory::Archive,
                "Expected Archive for .{ext}"
            );
        }
    }

    #[test]
    fn folder_is_always_folder() {
        assert_eq!(
            categorize(&EntryKind::Directory, "rs"),
            FileCategory::Folder
        );
    }

    #[test]
    fn sort_dirs_before_files() {
        let tmp = temp_dir();
        let dir_path  = make_dir(tmp.path(), "zzz_folder");
        let file_path = make_file(tmp.path(), "aaa_file.txt", b"hello");

        let mut entries = vec![
            FileEntry::from_path(&file_path).unwrap(),
            FileEntry::from_path(&dir_path).unwrap(),
        ];
        sort_entries(&mut entries, "name", true);

        assert!(entries[0].is_dir(), "Folder must sort first");
        assert!(!entries[1].is_dir(), "File must sort second");
    }

    #[test]
    fn file_entry_size_display() {
        let tmp = temp_dir();
        let path = make_file(tmp.path(), "large.bin", &vec![0u8; 2048]);
        let entry = FileEntry::from_path(&path).unwrap();
        let display = entry.size_display();
        // Should produce a human-readable string like "2.05 kB"
        assert!(!display.is_empty());
        assert!(display.contains('k') || display.contains('B'));
    }

    #[test]
    fn hidden_file_detection() {
        let tmp = temp_dir();
        let hidden = make_file(tmp.path(), ".hidden_file", b"");
        let visible = make_file(tmp.path(), "visible_file.txt", b"");

        let h = FileEntry::from_path(&hidden).unwrap();
        let v = FileEntry::from_path(&visible).unwrap();

        assert!(h.is_hidden, ".hidden_file should be hidden");
        assert!(!v.is_hidden, "visible_file.txt should not be hidden");
    }

    #[test]
    fn encrypted_file_marker() {
        let tmp = temp_dir();
        let enc = make_file(tmp.path(), "secret.txt.enc", b"encrypted");
        let entry = FileEntry::from_path(&enc).unwrap();
        assert!(entry.is_encrypted, ".enc files should be marked encrypted");
    }
}

// ── File system repository tests ──────────────────────────────────────────────

#[cfg(test)]
mod fs_tests {
    use super::*;
    use file_browser::fs::repository::*;

    #[test]
    fn list_dir_returns_entries() {
        let tmp = temp_dir();
        make_file(tmp.path(), "a.txt", b"a");
        make_file(tmp.path(), "b.txt", b"b");
        make_dir(tmp.path(), "subdir");

        let entries = list_dir(tmp.path()).expect("list_dir failed");
        assert_eq!(entries.len(), 3);
    }

    #[test]
    fn list_dir_sorted_dirs_first() {
        let tmp = temp_dir();
        make_file(tmp.path(), "z_file.txt", b"z");
        make_dir(tmp.path(), "a_dir");

        let entries = list_dir_sorted(tmp.path(), "name", true).unwrap();
        assert!(entries[0].is_dir(), "Directory must come first in sorted listing");
    }

    #[test]
    fn create_dir_success() {
        let tmp = temp_dir();
        let new_dir = tmp.path().join("new_folder");
        create_dir(&new_dir).expect("create_dir failed");
        assert!(new_dir.exists() && new_dir.is_dir());
    }

    #[test]
    fn create_dir_rejects_existing() {
        let tmp = temp_dir();
        let existing = make_dir(tmp.path(), "exists");
        let result = create_dir(&existing);
        assert!(result.is_err(), "create_dir should fail for existing directory");
    }

    #[test]
    fn rename_file() {
        let tmp = temp_dir();
        let src = make_file(tmp.path(), "old.txt", b"data");
        let dst = tmp.path().join("new.txt");
        rename(&src, &dst).expect("rename failed");
        assert!(!src.exists(), "Source should be gone after rename");
        assert!(dst.exists(), "Destination should exist after rename");
    }

    #[test]
    fn copy_entry_creates_copy() {
        let tmp = temp_dir();
        let src = make_file(tmp.path(), "orig.txt", b"hello world");
        let dst_dir = make_dir(tmp.path(), "dest");
        copy_entry(&src, &dst_dir).expect("copy_entry failed");

        let copied = dst_dir.join("orig.txt");
        assert!(copied.exists(), "Copy should exist at destination");

        let content = std::fs::read_to_string(&copied).unwrap();
        assert_eq!(content, "hello world");
    }

    #[test]
    fn copy_dir_recursive() {
        let tmp = temp_dir();
        let src_dir = make_dir(tmp.path(), "src_dir");
        make_file(&src_dir, "inner.txt", b"inner");
        let inner_dir = make_dir(&src_dir, "nested");
        make_file(&inner_dir, "deep.txt", b"deep");

        let dst_dir = make_dir(tmp.path(), "dst_dir");
        copy_entry(&src_dir, &dst_dir).expect("copy_entry dir failed");

        assert!(dst_dir.join("src_dir").join("inner.txt").exists());
        assert!(dst_dir.join("src_dir").join("nested").join("deep.txt").exists());
    }

    #[test]
    fn dir_size_calculation() {
        let tmp = temp_dir();
        make_file(tmp.path(), "f1.bin", &vec![0u8; 1000]);
        make_file(tmp.path(), "f2.bin", &vec![0u8; 2000]);

        let size = dir_size(tmp.path());
        assert_eq!(size, 3000, "Total size should be 3000 bytes");
    }

    #[test]
    fn read_text_preview_limited() {
        let tmp = temp_dir();
        let content = "A".repeat(10_000);
        let path = make_file(tmp.path(), "big.txt", content.as_bytes());

        let preview = read_text_preview(&path, 256).unwrap();
        assert_eq!(preview.len(), 256, "Preview should be limited to 256 bytes");
    }

    #[test]
    fn null_byte_in_path_rejected() {
        let bad_path = std::path::Path::new("some/\0bad/path");
        let result = validate_path(bad_path);
        assert!(result.is_err(), "Null byte in path must be rejected");
    }
}

// ── Archive tests ─────────────────────────────────────────────────────────────

#[cfg(test)]
mod archive_tests {
    use super::*;
    use file_browser::fs::archive::*;

    #[test]
    fn compress_and_extract_roundtrip() {
        let tmp = temp_dir();

        // Create source files
        let f1 = make_file(tmp.path(), "hello.txt", b"Hello, World!");
        let f2 = make_file(tmp.path(), "data.bin", &[1u8, 2, 3, 4, 5]);

        // Compress
        let zip_path = tmp.path().join("output.zip");
        compress(&[f1, f2], &zip_path, |_, _, _| {}).expect("compress failed");
        assert!(zip_path.exists(), "ZIP file should exist");
        assert!(zip_path.metadata().unwrap().len() > 0, "ZIP should not be empty");

        // List
        let names = list_archive(&zip_path).expect("list_archive failed");
        assert_eq!(names.len(), 2);

        // Extract
        let extract_dir = make_dir(tmp.path(), "extracted");
        let extracted = extract(&zip_path, &extract_dir).expect("extract failed");
        assert_eq!(extracted.len(), 2);

        // Verify content
        let hello = std::fs::read_to_string(extract_dir.join("hello.txt")).unwrap();
        assert_eq!(hello, "Hello, World!");
    }

    #[test]
    fn extract_sanitises_traversal_paths() {
        // This test constructs a malicious ZIP in memory and verifies
        // our sanitiser strips the traversal components.
        // We skip actual ZIP construction here and test the sanitiser directly.
        // (Full malicious ZIP test would require building one with the zip crate.)
        let malicious = "../../../etc/passwd";
        let path = std::path::Path::new(malicious);
        let sanitised: std::path::PathBuf = path
            .components()
            .filter(|c| matches!(c, std::path::Component::Normal(_)))
            .collect();
        assert_eq!(sanitised.to_str().unwrap(), "etc/passwd");
    }
}

// ── Encryption tests ──────────────────────────────────────────────────────────

#[cfg(test)]
mod encryption_tests {
    use super::*;
    use file_browser::security::encryption::*;

    #[test]
    fn encrypt_decrypt_roundtrip() {
        let tmp = temp_dir();
        let original = b"This is secret content. Do not share.";
        let src = make_file(tmp.path(), "secret.txt", original);

        let password = "correct-horse-battery-staple";

        // Encrypt
        let enc_path = encrypt_file(&src, password).expect("encrypt failed");
        assert!(enc_path.exists(), "Encrypted file should exist");
        assert_ne!(
            std::fs::read(&enc_path).unwrap().as_slice(),
            original,
            "Encrypted content must differ from plaintext"
        );

        // Decrypt
        let dec_path = decrypt_file(&enc_path, password).expect("decrypt failed");
        let decrypted = std::fs::read(&dec_path).unwrap();
        assert_eq!(decrypted.as_slice(), original, "Decrypted content must match original");
    }

    #[test]
    fn wrong_password_returns_error() {
        let tmp = temp_dir();
        let src = make_file(tmp.path(), "test.txt", b"sensitive data");
        let enc_path = encrypt_file(&src, "correct-password").expect("encrypt");
        let result = decrypt_file(&enc_path, "wrong-password");
        assert!(result.is_err(), "Wrong password must return error");
    }

    #[test]
    fn tampered_ciphertext_fails() {
        let tmp = temp_dir();
        let src = make_file(tmp.path(), "test.txt", b"data");
        let enc_path = encrypt_file(&src, "pass").expect("encrypt");

        // Tamper with the ciphertext bytes (after the 32-byte header)
        let mut data = std::fs::read(&enc_path).unwrap();
        if let Some(byte) = data.get_mut(40) {
            *byte ^= 0xFF;
        }
        std::fs::write(&enc_path, &data).unwrap();

        let result = decrypt_file(&enc_path, "pass");
        assert!(result.is_err(), "Tampered ciphertext must be rejected by AES-GCM");
    }

    #[test]
    fn different_files_same_password_different_ciphertext() {
        let tmp = temp_dir();
        let f1 = make_file(tmp.path(), "f1.txt", b"same content");
        let f2 = make_file(tmp.path(), "f2.txt", b"same content");

        let enc1 = encrypt_file(&f1, "password").expect("enc1");
        let enc2 = encrypt_file(&f2, "password").expect("enc2");

        let data1 = std::fs::read(&enc1).unwrap();
        let data2 = std::fs::read(&enc2).unwrap();
        // Different salts → different ciphertexts (semantic security)
        assert_ne!(data1, data2, "Identical plaintexts must produce different ciphertexts");
    }
}

// ── Config tests ──────────────────────────────────────────────────────────────

#[cfg(test)]
mod config_tests {
    use file_browser::core::config::Config;

    #[test]
    fn default_config_is_valid() {
        let config = Config::default();
        assert!(!config.start_path.is_empty());
        assert_eq!(config.view_mode, "grid");
        assert_eq!(config.sort_by, "name");
    }

    #[test]
    fn add_recent_deduplicates_and_caps() {
        let mut config = Config::default();
        // Add 60 items
        for i in 0..60 {
            config.add_recent(format!("/path/{i}"));
        }
        assert!(config.recent_paths.len() <= 50, "Recent paths should be capped at 50");
    }

    #[test]
    fn add_recent_moves_existing_to_front() {
        let mut config = Config::default();
        config.add_recent("/path/a");
        config.add_recent("/path/b");
        config.add_recent("/path/a"); // re-add

        assert_eq!(config.recent_paths[0], "/path/a");
        assert_eq!(config.recent_paths.len(), 2, "Duplicate should be removed");
    }

    #[test]
    fn toggle_favorite_adds_and_removes() {
        let mut config = Config::default();
        config.toggle_favorite("/some/path");
        assert!(config.is_favorite("/some/path"));

        config.toggle_favorite("/some/path");
        assert!(!config.is_favorite("/some/path"));
    }
}

// ── Search tests ──────────────────────────────────────────────────────────────

#[cfg(test)]
mod search_tests {
    use super::*;
    use file_browser::fs::search::*;
    use std::sync::{Arc, atomic::AtomicBool};

    #[test]
    fn search_by_name() {
        let tmp = temp_dir();
        make_file(tmp.path(), "document.pdf", b"pdf");
        make_file(tmp.path(), "photo.jpg", b"jpg");
        make_file(tmp.path(), "notes.txt", b"txt");

        let cancel = Arc::new(AtomicBool::new(false));
        let results = search_dir(
            tmp.path(),
            &SearchQuery::from_name("photo"),
            100,
            cancel,
        ).unwrap();

        assert_eq!(results.len(), 1);
        assert_eq!(results[0].name, "photo.jpg");
    }

    #[test]
    fn search_by_extension() {
        let tmp = temp_dir();
        make_file(tmp.path(), "a.rs", b"fn main() {}");
        make_file(tmp.path(), "b.py", b"print('hello')");
        make_file(tmp.path(), "c.rs", b"// rust");

        let cancel = Arc::new(AtomicBool::new(false));
        let results = search_dir(
            tmp.path(),
            &SearchQuery { extension: Some("rs".into()), ..Default::default() },
            100,
            cancel,
        ).unwrap();

        assert_eq!(results.len(), 2, "Should find exactly 2 .rs files");
    }

    #[test]
    fn empty_query_returns_nothing() {
        let tmp = temp_dir();
        make_file(tmp.path(), "file.txt", b"");

        let cancel = Arc::new(AtomicBool::new(false));
        let results = search_dir(
            tmp.path(),
            &SearchQuery::default(),
            100,
            cancel,
        ).unwrap();

        assert!(results.is_empty(), "Empty query should return no results");
    }

    #[test]
    fn search_hidden_files_excluded_by_default() {
        let tmp = temp_dir();
        make_file(tmp.path(), ".hidden", b"h");
        make_file(tmp.path(), "visible.txt", b"v");

        let cancel = Arc::new(AtomicBool::new(false));
        let results = search_dir(
            tmp.path(),
            &SearchQuery { name: "hidden".into(), include_hidden: false, ..Default::default() },
            100,
            cancel,
        ).unwrap();

        assert!(results.is_empty(), ".hidden file should be excluded");
    }

    #[test]
    fn search_content() {
        let tmp = temp_dir();
        make_file(tmp.path(), "match.txt",   b"The quick brown fox");
        make_file(tmp.path(), "nomatch.txt", b"Nothing relevant here");

        let cancel = Arc::new(AtomicBool::new(false));
        let results = search_dir(
            tmp.path(),
            &SearchQuery {
                name:    String::new(),
                content: Some("quick brown".into()),
                ..Default::default()
            },
            100,
            cancel,
        ).unwrap();

        assert_eq!(results.len(), 1);
        assert_eq!(results[0].name, "match.txt");
    }
}
