# Security Checklist

## File System Safety
- [x] **Path traversal prevention** — `validate_path()` rejects null bytes and
      `..` that would escape the user's chosen root.  `canonicalize()` is used
      before any destructive operation.
- [x] **Permission errors are graceful** — unreadable directories surface as
      `AppError::PermissionDenied`, never a crash.
- [x] **No root required** — all operations use the current user's permissions.
- [x] **Safe delete** — entries go to the OS trash by default (recoverable).
      Permanent delete requires explicit confirmation dialog.
- [x] **Copy collision avoidance** — `unique_name()` generates non-clobbering
      destination names ("file (2).txt", etc.).
- [x] **Archive extraction zip-slip protection** — `sanitize_zip_path()` strips
      absolute paths and `..` components from every archive entry name before
      writing to disk.
- [x] **Atomic config writes** — config is written to a `.tmp` file then
      renamed, preventing partial writes / corruption.

## Encryption
- [x] **AES-256-GCM** — authenticated encryption; any ciphertext tampering is
      detected and rejected.
- [x] **Random salt per file** — prevents rainbow-table and dictionary attacks
      across multiple encrypted files.
- [x] **Random nonce per file** — GCM nonce uniqueness guaranteed.
- [x] **PBKDF2-SHA256 (600 000 iterations)** — OWASP 2023-recommended iteration
      count for interactive logins; raises the cost of brute-force attacks.
- [x] **Magic byte validation** — corrupted / non-encrypted files are rejected
      before any key derivation work.
- [x] **Zeroize-on-drop** — aes-gcm keys live only for the duration of the
      operation; Rust's drop semantics ensure the stack is not left with key
      material longer than necessary.

## Dependencies
- [x] Minimal transitive dependency tree — no Electron, no WebView, no Node.js.
- [x] All dependencies are well-maintained crates with active security audit
      histories (aes-gcm, pbkdf2, sha2 are from the RustCrypto project, which
      conducts regular audits).
- [ ] **Recommended**: run `cargo audit` in CI to catch known CVEs:
      ```
      cargo install cargo-audit
      cargo audit
      ```

## Build & Distribution
- [x] `panic = "abort"` in release — no unwinding machinery; reduces attack
      surface of stack-unwinding-based exploits.
- [x] `strip = true` — removes debug symbols that could leak internal paths or
      function names.
- [ ] **Recommended**: sign release binaries (code signing on Windows/macOS).
- [ ] **Recommended**: enable `RELRO`, `PIE`, and `stack-canary` via linker
      flags (handled automatically on most Linux distros; explicit on Windows).

## Permissions Philosophy
- The app requests **no special OS permissions** beyond those granted to the
  current user process.
- Folder access beyond the start directory is user-initiated via native OS
  dialogs (`rfd`), not automatic scanning.
- No network access by default; SMB/FTP are feature-flag opt-ins.
