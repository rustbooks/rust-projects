# Changelog

All notable changes to File Browser will be documented in this file.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [Unreleased]

### Added
- Initial production-ready release
- Material You-inspired UI built with Slint 1.x — no WebView, no Electron
- Grid and list view modes with virtualised rendering
- Full keyboard navigation (Ctrl+C/X/V/N/H/R, F2, F5, Delete, Backspace)
- Breadcrumb navigation with clickable path segments
- Sidebar with Quick Access, Favourites, and Devices sections
- Dark / Light theme toggle (persisted in config)
- AES-256-GCM file encryption with PBKDF2-SHA256 key derivation
- ZIP archive creation and extraction with zip-slip protection
- Parallel file search (name, content, extension, size, date) via Rayon
- Native folder picker via `rfd` (no WebView dependency)
- Send-to-trash (OS trash) with fallback to permanent delete
- Copy, Cut, Paste with cross-device move support
- Rename with unique-name collision avoidance
- Live directory watching via `notify` crate
- Persistent JSON config (start path, theme, view mode, favourites, recents)
- Sort by name / size / date / type with ascending/descending toggle
- Hidden file toggle (.dotfiles on Unix, FILE_ATTRIBUTE_HIDDEN on Windows)
- Storage usage analysis (`dir_size`)
- Drive/volume enumeration (Windows letters, macOS /Volumes, Linux /media /mnt)
- Standard locations sidebar (Home, Desktop, Documents, Downloads, Pictures, Music, Videos)
- Toast notifications (auto-dismiss 3 s)
- Responsive layout — from 480 px phone to 98-inch TV via single Slint design
- GitHub Actions CI: format, lint, test, release build, security audit
- Flatpak manifest for Linux distribution
- WiX installer config for Windows MSI
- Makefile with dev/release/test/audit/size targets
- Full integration test suite: domain, FS, archive, encryption, config, search

### Architecture
- Clean Architecture: core / domain / fs / security / ui
- Repository pattern for all filesystem operations
- Arc<Mutex<AppState>> shared state — bridge marshals to Slint event loop
- Tokio multi-threaded runtime for non-blocking FS operations
- All destructive operations path-validated before execution

## [Future Roadmap]

### Planned
- [ ] Image thumbnail previews (fast via image crate)
- [ ] PDF first-page preview
- [ ] Dual-pane mode (side-by-side)
- [ ] Drag & drop (Slint 1.x drag-drop support)
- [ ] Network shares (SMB/FTP) via `network` feature flag
- [ ] Storage usage pie chart (Slint canvas)
- [ ] Batch rename with regex patterns
- [ ] File integrity SHA-256 checksums in properties dialog
- [ ] Android SAF (Storage Access Framework) via JNI bridge
- [ ] macOS Quick Look integration
- [ ] Windows thumbnail shell extension
