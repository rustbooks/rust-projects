// build.rs — Slint UI compiler
//
// Slint compiles .slint files at build time into Rust code.
// This is zero-overhead: the UI definitions are baked into the binary.
// No runtime template parsing = fast startup, small footprint.

fn main() {
    let config = slint_build::CompilerConfiguration::new()
        .with_style("fluent".into()); // Material You via Fluent style

    slint_build::compile_with_config("ui/app.slint", config)
        .expect("Slint compilation failed");
}
